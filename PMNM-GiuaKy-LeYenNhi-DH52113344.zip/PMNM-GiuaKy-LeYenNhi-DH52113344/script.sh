#!/bin/sh

FILE="users.txt"

if [ ! -f "$FILE" ]; then
    echo "File $FILE not found!"
    exit 1
fi

while IFS= read -r username; do
    # Skip empty lines
    [[ -z "$username" ]] && continue

    # Validate username: more than 4 characters and starts with "TH"
    if [[ ${#username} -le 4 || ! "$username" =~ ^TH ]]; then
        echo "Invalid username '$username'. Must be more than 4 characters and start with 'TH'. Skipping."
        continue
    fi

    # Check if the user already exists
    if id "$username" &>/dev/null; then
        echo "User $username already exists."
    else
        # Create the user if they don't exist
        if useradd "$username"; then
            echo "User $username created successfully."
        else
            echo "Failed to create user $username."
        fi
    fi
done < "$FILE"

